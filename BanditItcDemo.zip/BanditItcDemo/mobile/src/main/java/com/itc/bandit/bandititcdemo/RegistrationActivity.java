package com.itc.bandit.bandititcdemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;




public class RegistrationActivity extends Activity {

	EditText First_New, Second_Name, Email, Password_new;
	Button register_btn;
	SharedPreferences sh_Pref;
	Editor toEdit;
	String first, second, email, password, m_wlanMacAdd;
	//Form mForm;
	//Validate emailField, firstname, last_name, pwd;
	String url ="http://localhost:8080/WTPExample/snoop/";
	String TAG = "Registration_Activity";
	private ProgressDialog pDialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration);

		First_New = (EditText) findViewById(R.id.first_name);
		Second_Name = (EditText) findViewById(R.id.second_name);
		Email = (EditText) findViewById(R.id.email);
		Password_new = (EditText) findViewById(R.id.Password);
		register_btn = (Button) findViewById(R.id.register);

		register_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				first = First_New.getText().toString();
				second = Second_Name.getText().toString();
				email = Email.getText().toString();

			//	validationField();

               
				password = Password_new.getText().toString();
				WifiManager m_wm = (WifiManager) getSystemService(Context.WIFI_SERVICE);
				m_wlanMacAdd = m_wm.getConnectionInfo().getMacAddress();
				Log.v(TAG, "m_wlanMacAdd" + m_wlanMacAdd);
				
				 Intent i = new Intent(getApplicationContext(),
                        MapsActivity.class);
                startActivity(i);
			//	sharedPrefernces();

			}
		});
	}

/*	public void validationField() {

		emailField = new Validate(Email);
		emailField.addValidator(new NotEmptyValidator(this));
		emailField.addValidator(new EmailValidator(this));

		firstname = new Validate(First_New);
		firstname.addValidator(new NotEmptyValidator(this));

		last_name = new Validate(Second_Name);
		last_name.addValidator(new NotEmptyValidator(this));

		pwd = new Validate(Password_new);
		pwd.addValidator(new NotEmptyValidator(this));

		mForm = new Form();
		mForm.addValidates(emailField);
		mForm.addValidates(firstname);
		mForm.addValidates(last_name);
		mForm.addValidates(pwd);

		if (mForm.validate()) {
			// success statement
			new GetContacts().execute();
			
			Intent i = new Intent(getApplicationContext(),
					MapsActivity.class);
			startActivity(i);
		} else {
			// error statement like toast, crouton, ...
		}

	}
	*/
	private class GetContacts extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			// Showing progress dialog
			pDialog = new ProgressDialog(RegistrationActivity.this);
			pDialog.setMessage("Please wait...");
			pDialog.setCancelable(false);
			pDialog.show();

		}

		@Override
		protected Void doInBackground(Void... arg0) {
			// Creating service handler class instance

			sendData();

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			// Dismiss the progress dialog
			if (pDialog.isShowing())
				pDialog.dismiss();

		}

	}
	public void sendData(){
		
		
		 InputStream inputStream = null;
	        String result = "";
	        try {

	            // 1. create HttpClient
	            HttpClient httpclient = new DefaultHttpClient();

	            // 2. make POST request to the given URL
	            HttpPost httpPost = new HttpPost(url);

	            String json = "";

	            // 3. build jsonObject
	            JSONObject jsonObject = new JSONObject();
	            jsonObject.accumulate("First_Name",first );
	            jsonObject.accumulate("Last_Name",second );
	            jsonObject.accumulate("Email_ID",email );
	            jsonObject.accumulate("Comments",password );
	            jsonObject.accumulate("Device_ID",m_wlanMacAdd );
	            jsonObject.accumulate("User_ID"," " );
	            jsonObject.accumulate("Token_ID"," " );
	            jsonObject.accumulate("Created_On"," " );
	            jsonObject.accumulate("Modified_On"," " );
	            jsonObject.accumulate("Modified_By"," " );

	            // 4. convert JSONObject to JSON to String
	            json = jsonObject.toString();

	            // ** Alternative way to convert Person object to JSON string usin Jackson Lib 
	            // ObjectMapper mapper = new ObjectMapper();
	            // json = mapper.writeValueAsString(person); 

	            // 5. set json to StringEntity
	            StringEntity se = new StringEntity(json);

	            // 6. set httpPost Entity
	            httpPost.setEntity(se);

	            // 7. Set some headers to inform server about the type of the content   
	            httpPost.setHeader("Accept", "application/json");
	            httpPost.setHeader("Content-type", "application/json");

	            // 8. Execute POST request to the given URL
	            HttpResponse httpResponse = httpclient.execute(httpPost);

	            // 9. receive response as inputStream
	            inputStream = httpResponse.getEntity().getContent();

	            // 10. convert inputstream to string
	            if(inputStream != null){
	                result = convertInputStreamToString(inputStream);
	            }
	            else{
	                result = "Did not work!";
	            }
	            System.out.println("Result from app is "+result);

	        } catch (Exception e) {
	            Log.d("InputStream", e.getLocalizedMessage());
	        }

	        // 11. return result
	        //return result;
	}
	
		private static String convertInputStreamToString(InputStream inputStream) throws IOException{
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }   


	/*public void sharedPrefernces()

	{
		sh_Pref = getSharedPreferences("Login Credentials", MODE_PRIVATE);
		toEdit = sh_Pref.edit();
		toEdit.putString("Firstname", first);
		toEdit.putString("Secondname", second);
		toEdit.putString("E_mail", email);
		toEdit.putString("Password_New", password);
		// toEdit.putString("MacId", m_wlanMacAdd);
		toEdit.commit();
		Toast.makeText(this, "Details are saved", 20).show();
	}
*/
}
