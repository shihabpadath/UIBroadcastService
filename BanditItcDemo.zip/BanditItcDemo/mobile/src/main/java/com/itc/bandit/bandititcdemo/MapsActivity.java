package com.itc.bandit.bandititcdemo;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends Activity {

	private GoogleMap mMap; // Might be null if Google Play services APK is not
	// available.
	private double mLatitude, mLongitude;
	
	private JSONObject json = null;
	

	String url1 = "https://198.20.12.2/";

	private BroadcastReceiver mReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			Toast.makeText(MapsActivity.this,
					"Checking if you have some new deal", Toast.LENGTH_SHORT)
					.show();
			if (intent != null) {
				mLatitude = intent.getDoubleExtra("LatValue", 0.0);
				mLongitude = intent.getDoubleExtra("LongValue", 0.0);
			}
			setUpMapIfNeeded();
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_maphome);
		
		new DealAccess().execute();
		//start the service that will check every after 1 min if location is changed or not
		//and if change it will send broadcast to map activity that will update itself
		startService(new Intent(this, GPSTracker.class));
		
	}



	@Override
	protected void onResume() {
		super.onResume();
		registerReceiver(mReceiver, new IntentFilter(GPSTracker.NOTIFICATION));
		
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		unregisterReceiver(mReceiver);
	}

	private void setUpMapIfNeeded() {
		// Do a null check to confirm that we have not already instantiated the
		// map.
		if (mMap == null) {
			// Try to obtain the map from the SupportMapFragment.
			mMap = ((MapFragment) getFragmentManager().findFragmentById(
					R.id.map)).getMap();

			// Check if we were successful in obtaining the map.
			if (mMap != null) {
				setUpMap();
			}
		}
	}

	private void setUpMap() {

		mMap.addMarker(new MarkerOptions().position(
				new LatLng(mLatitude, mLongitude)).icon(
				BitmapDescriptorFactory
						.fromResource(R.drawable.current_newicon)));

		CameraUpdate center = CameraUpdateFactory.newLatLng(new LatLng(
				mLatitude, mLongitude));
		CameraUpdate zoom = CameraUpdateFactory.zoomTo(8);

		mMap.moveCamera(center);
		mMap.animateCamera(zoom);
		
		mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {

            @Override
            public boolean onMarkerClick(Marker arg0) {

                if(json!=null){
                    Intent i = new Intent(getApplicationContext(),
                            OfferDetailsFragment.class);
                    i.putExtra("offerlist",json.toString());
                    Log.i("MapActivity","json"+json.toString());

                    startActivity(i);
                }
                else{
                   Toast.makeText(MapsActivity.this,"No deal at this place",Toast.LENGTH_SHORT).show();
                }

                return false;
            }
        });
		
	}
	
	class DealAccess extends AsyncTask<String, String, JSONObject> {

		/**
		 * Defining Process dialog
		 **/
		private ProgressDialog pDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			pDialog = new ProgressDialog(MapsActivity.this);
			pDialog.setTitle("Contacting Servers");
			pDialog.setMessage("Please Wait.. getting all available deal nearby you ...");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(true);
			pDialog.show();
		}

		@Override
		protected JSONObject doInBackground(String... args) {
			
			Log.i("MapActivity", "JSONObject doInBackground ");
			JSONParserResponse response = new JSONParserResponse();
			json = response.getJSONFromUrl(url1, mLatitude, mLongitude, "1");

			return json;

		}

		@Override
		protected void onPostExecute(JSONObject json) {
			/**
			 * Checks for success message.
			 **/
			Log.i("MapActivity", "onPostExecute");
			pDialog.dismiss();

		}
	}

  /*  @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        if(newConfig.orientation==Configuration.ORIENTATION_LANDSCAPE){

            Log.e("On Config Change","LANDSCAPE");
        }else{

            Log.e("On Config Change","PORTRAIT");
        }
    }*/
}
