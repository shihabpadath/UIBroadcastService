package com.itc.bandit.bandititcdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;

public class NetworkStatus {
	private final Context mContext;

	public NetworkStatus(Context context) {
		this.mContext = context;

	}

	ConnectivityManager connectivityManager;
	NetworkInfo wifiInfo, mobileInfo;
	boolean connected = false;

	public boolean isOnline() {
		try {
			connectivityManager = (ConnectivityManager) mContext
					.getSystemService(Context.CONNECTIVITY_SERVICE);

			NetworkInfo networkInfo = connectivityManager
					.getActiveNetworkInfo();
			connected = networkInfo != null && networkInfo.isAvailable()
					&& networkInfo.isConnectedOrConnecting();
			return connected;

		} catch (Exception e) {

		}
		return connected;
	}

	public void showInternetSettings() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
		alertDialog.setTitle("Internet Connection");
		alertDialog
				.setMessage("Internet is not available, Please check your internet connectivity and try again");
		alertDialog.setPositiveButton("Settings",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						Intent intent = new Intent(
								Settings.ACTION_WIRELESS_SETTINGS);
						mContext.startActivity(intent);
						((Activity) mContext).finish();

					}
				});
		alertDialog.setNegativeButton("Cancel",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						dialog.cancel();
						((Activity) mContext).finish();
					}
				});
		alertDialog.show();
	}
}
